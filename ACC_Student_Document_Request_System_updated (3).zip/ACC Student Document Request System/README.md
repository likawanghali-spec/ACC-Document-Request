# ACC Student Document Request System

A web-based system for **Abuyog Community College** that lets students request
school documents online and track their status, while authorized ACC staff
process and update those requests.

Built with **PHP (PDO/MySQL), MySQL, HTML, CSS and JavaScript** — green & white
ACC theme, no frameworks required.

## Features

- Student registration & login (passwords hashed with bcrypt)
- Submit a document request (Certificate of Enrollment, Good Moral, School
  Certification, Transcript of Records, Diploma copy, etc.)
- Track request status with a tracking number (e.g. `ACC-2026-00001`)
- Student dashboard with request stats
- Admin/staff login, dashboard, and request management
- Admin can filter/search requests and update status with remarks
  (Pending → Processing → Approved → Ready for Pickup → Released, or Rejected)
- Full status-change audit trail (`request_status_log` table)
- Registered students list for staff

## Folder Structure

```
ACC Student Document Request System/
├── assets/          CSS, JS, images
│   ├── css/style.css      (green & white theme)
│   └── js/script.js
├── config/          Database connection
│   └── db.php
├── controller/      Handles form submissions (login, register, requests)
│   ├── AuthController.php
│   └── RequestController.php
├── correct db/      SQL schema + seed data
│   └── acc_document_request.sql
├── lib/             Shared helper functions
│   └── functions.php
├── model/           Data-access classes (PDO)
│   ├── User.php
│   ├── DocumentType.php
│   └── DocumentRequest.php
├── views/
│   ├── partials/    Shared nav includes
│   ├── student/     Student dashboard, submit request, my requests
│   └── admin/       Admin dashboard, manage requests, students list
├── index.php        Entry point (redirects to login/dashboard)
├── login.php
└── register.php
```

## Setup Instructions (XAMPP / WAMP / LAMP)

1. **Copy the project folder** into your server's web root, e.g.
   `htdocs/ACC Student Document Request System` (XAMPP) or `www/...` (WAMP).

2. **Create the database.** Open phpMyAdmin (or the MySQL CLI) and import:
   ```
   correct db/acc_document_request.sql
   ```
   This creates the `acc_document_request` database, all tables, the 5 default
   document types, one admin account, and one sample student account.

3. **Configure the DB connection.** Edit `config/db.php` if your MySQL
   username/password differ from the defaults (`root` / empty password):
   ```php
   define('DB_USER', 'root');
   define('DB_PASS', '');
   ```

4. **Start Apache + MySQL** (via XAMPP/WAMP control panel).

5. **Open the app** in your browser:
   ```
   http://localhost/ACC Student Document Request System/
   ```
   (Or rename the folder to something without spaces, e.g. `acc-docs`, if your
   server has trouble with spaces in the URL.)

## Default Accounts

| Role    | Email                        | Password  |
|---------|-------------------------------|-----------|
| Admin   | admin@acc.edu.ph              | admin123  |
| Student | juan@student.acc.edu.ph       | admin123  |

**Change these passwords after your first login in a real deployment.**
You can also just register a brand-new student account from the Register page.

## System Flow

```
ACC Student → submits Document Request → ACC Staff reviews
   → Staff updates status (Processing → Approved → Ready for Pickup → Released)
   → Student checks status anytime via "My Requests"
```

## Notes

- All database queries use PDO prepared statements to prevent SQL injection.
- Passwords are hashed with PHP's `password_hash()` (bcrypt) and never stored
  in plain text.
- Sessions are used for authentication; `require_role()` in `lib/functions.php`
  guards every protected page.
- To add a new document type (e.g. "Good Moral for Transferees"), insert a row
  into the `document_types` table — it will automatically appear on the
  student's request form.
