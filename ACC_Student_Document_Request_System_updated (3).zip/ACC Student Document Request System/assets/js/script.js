/* =========================================================
   ACC Student Document Request System
   Client-side JavaScript
   ========================================================= */

document.addEventListener('DOMContentLoaded', function () {

    // Sidebar: mobile open/close toggle
    var sidebarToggle = document.querySelector('.sidebar-toggle');
    var sidebar = document.querySelector('.sidebar');
    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', function () {
            sidebar.classList.toggle('open');
        });
        document.addEventListener('click', function (e) {
            if (sidebar.classList.contains('open') &&
                !sidebar.contains(e.target) &&
                !sidebarToggle.contains(e.target)) {
                sidebar.classList.remove('open');
            }
        });
    }

    // Auto-hide flash alerts after 4 seconds
    document.querySelectorAll('.alert').forEach(function (alert) {
        setTimeout(function () {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(function () { alert.remove(); }, 500);
        }, 4000);
    });

    // Highlight selected document type card in the request form
    document.querySelectorAll('.doc-type-option').forEach(function (option) {
        var radio = option.querySelector('input[type="radio"]');
        if (!radio) return;

        function refresh() {
            document.querySelectorAll('.doc-type-option').forEach(function (o) {
                o.style.borderColor = '';
                o.style.background = '';
            });
            if (radio.checked) {
                option.style.borderColor = '#1a8a44';
                option.style.background = '#e6f7ec';
            }
        }

        radio.addEventListener('change', function () {
            document.querySelectorAll('.doc-type-option input[type="radio"]').forEach(function (r) {
                r.closest('.doc-type-option').style.borderColor = '';
                r.closest('.doc-type-option').style.background = '';
            });
            refresh();
        });

        if (radio.checked) refresh();
    });

    // Register / login form: basic client-side validation
    var registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function (e) {
            var pass = document.getElementById('password');
            var confirm = document.getElementById('confirm_password');
            if (pass && confirm && pass.value !== confirm.value) {
                e.preventDefault();
                alert('Passwords do not match. Please check and try again.');
            }
        });
    }

    // Submit-request form: require a document type to be chosen
    var submitForm = document.getElementById('submitRequestForm');
    if (submitForm) {
        submitForm.addEventListener('submit', function (e) {
            var checked = submitForm.querySelector('input[name="document_type_id"]:checked');
            if (!checked) {
                e.preventDefault();
                alert('Please select the document type you want to request.');
            }
        });
    }

    // Admin: update-status modal-like inline form toggle
    document.querySelectorAll('.js-toggle-update').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var id = btn.getAttribute('data-target');
            var row = document.getElementById(id);
            if (row) {
                row.style.display = (row.style.display === 'table-row') ? 'none' : 'table-row';
            }
        });
    });

    // Search/filter form on admin manage-requests page: auto-submit on select change
    var statusFilter = document.getElementById('statusFilter');
    if (statusFilter) {
        statusFilter.addEventListener('change', function () {
            statusFilter.form.submit();
        });
    }
});
