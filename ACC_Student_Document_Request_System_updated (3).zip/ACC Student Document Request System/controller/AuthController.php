<?php
/**
 * ACC Student Document Request System
 * AuthController - handles login / register / logout POST actions
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../lib/functions.php';
require_once __DIR__ . '/../model/User.php';

$action = $_POST['action'] ?? '';
$userModel = new User($pdo);

if ($action === 'login') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        set_flash('error', 'Please enter both email and password.');
        redirect('/login.php');
    }

    $user = $userModel->findByEmail($email);

    if (!$user || !$userModel->verifyPassword($password, $user['password'])) {
        set_flash('error', 'Invalid email or password.');
        redirect('/login.php');
    }

    if ($user['status'] === 'inactive') {
        set_flash('error', 'Your account has been deactivated. Please contact the registrar.');
        redirect('/login.php');
    }

    $_SESSION['user_id']   = $user['id'];
    $_SESSION['full_name'] = $user['full_name'];
    $_SESSION['role']      = $user['role'];

    if ($user['role'] === 'admin') {
        redirect('/views/admin/dashboard.php');
    } else {
        redirect('/views/student/dashboard.php');
    }
}

if ($action === 'register') {
    $studentId  = trim($_POST['student_id'] ?? '');
    $fullName   = trim($_POST['full_name'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $course     = trim($_POST['course'] ?? '');
    $yearLevel  = trim($_POST['year_level'] ?? '');
    $contact    = trim($_POST['contact_number'] ?? '');
    $password   = $_POST['password'] ?? '';
    $confirm    = $_POST['confirm_password'] ?? '';

    if ($studentId === '' || $fullName === '' || $email === '' || $password === '') {
        set_flash('error', 'Please fill in all required fields.');
        redirect('/register.php');
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        set_flash('error', 'Please enter a valid email address.');
        redirect('/register.php');
    }

    if ($password !== $confirm) {
        set_flash('error', 'Passwords do not match.');
        redirect('/register.php');
    }

    if (strlen($password) < 6) {
        set_flash('error', 'Password must be at least 6 characters.');
        redirect('/register.php');
    }

    if ($userModel->emailExists($email)) {
        set_flash('error', 'That email is already registered.');
        redirect('/register.php');
    }

    if ($userModel->studentIdExists($studentId)) {
        set_flash('error', 'That Student ID is already registered.');
        redirect('/register.php');
    }

    $userModel->createStudent([
        'student_id'     => $studentId,
        'full_name'      => $fullName,
        'email'          => $email,
        'password'       => $password,
        'course'         => $course,
        'year_level'     => $yearLevel,
        'contact_number' => $contact,
    ]);

    set_flash('success', 'Account created successfully! You may now log in.');
    redirect('/login.php');
}

if ($action === 'logout') {
    session_unset();
    session_destroy();
    redirect('/login.php');
}

// No valid action supplied
redirect('/login.php');
