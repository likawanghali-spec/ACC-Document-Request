<?php
/**
 * ACC Student Document Request System
 * RequestController - handles request submission and status updates
 */

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../lib/functions.php';
require_once __DIR__ . '/../model/DocumentRequest.php';

$action = $_POST['action'] ?? '';
$requestModel = new DocumentRequest($pdo);

/* ---------------- Student: submit a new request ---------------- */
if ($action === 'submit_request') {
    require_role('student');

    $documentTypeId = (int) ($_POST['document_type_id'] ?? 0);
    $purpose        = trim($_POST['purpose'] ?? '');
    $copies         = max(1, (int) ($_POST['number_of_copies'] ?? 1));

    if ($documentTypeId <= 0 || $purpose === '') {
        set_flash('error', 'Please choose a document type and state your purpose.');
        redirect('/views/student/submit_request.php');
    }

    $trackingNo = $requestModel->create($_SESSION['user_id'], $documentTypeId, $purpose, $copies);

    set_flash('success', "Request submitted! Your tracking number is $trackingNo.");
    redirect('/views/student/my_requests.php');
}

/* ---------------- Admin: update a request's status ---------------- */
if ($action === 'update_status') {
    require_role('admin');

    $requestId = (int) ($_POST['request_id'] ?? 0);
    $newStatus = trim($_POST['status'] ?? '');
    $remarks   = trim($_POST['remarks'] ?? '');

    $validStatuses = ['Pending', 'Processing', 'Approved', 'Ready for Pickup', 'Released', 'Rejected'];
    if ($requestId <= 0 || !in_array($newStatus, $validStatuses, true)) {
        set_flash('error', 'Invalid request or status.');
        redirect('/views/admin/manage_requests.php');
    }

    $requestModel->updateStatus($requestId, $newStatus, $_SESSION['user_id'], $remarks ?: null);

    set_flash('success', 'Request status updated successfully.');
    redirect('/views/admin/manage_requests.php');
}

redirect('/index.php');
