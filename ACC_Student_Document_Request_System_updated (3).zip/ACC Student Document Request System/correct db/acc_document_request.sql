-- =========================================================
-- ACC Student Document Request System
-- Database: acc_document_request
-- =========================================================

CREATE DATABASE IF NOT EXISTS acc_document_request
  CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE acc_document_request;

-- ---------------------------------------------------------
-- Table: users  (students + admin/staff accounts)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20) UNIQUE NULL,        -- ACC student number (NULL for staff)
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(120) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('student','admin') NOT NULL DEFAULT 'student',
    course VARCHAR(120) NULL,
    year_level VARCHAR(20) NULL,
    contact_number VARCHAR(20) NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Table: document_types
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS document_types (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description TEXT NULL,
    processing_days INT NOT NULL DEFAULT 3,
    is_active TINYINT(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB;

INSERT INTO document_types (name, description, processing_days) VALUES
('Certificate of Enrollment', 'Official certification that the student is currently enrolled for the current term.', 2),
('Certificate of Good Moral Character', 'Certifies the good moral standing/conduct of the student.', 3),
('School Certification', 'General purpose school certification document.', 3),
('Transcript of Records', 'Certified copy of the student''s official academic records.', 5),
('Diploma / Certificate of Graduation', 'Certified true copy of diploma or graduation certificate.', 5);

-- ---------------------------------------------------------
-- Table: requests
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tracking_no VARCHAR(20) UNIQUE NOT NULL,
    student_id INT NOT NULL,
    document_type_id INT NOT NULL,
    purpose VARCHAR(255) NOT NULL,
    number_of_copies INT NOT NULL DEFAULT 1,
    status ENUM('Pending','Processing','Approved','Ready for Pickup','Released','Rejected')
        NOT NULL DEFAULT 'Pending',
    remarks TEXT NULL,
    date_requested TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    processed_by INT NULL,
    FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (document_type_id) REFERENCES document_types(id),
    FOREIGN KEY (processed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Table: request_status_log  (audit trail of status changes)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS request_status_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    request_id INT NOT NULL,
    old_status VARCHAR(30) NULL,
    new_status VARCHAR(30) NOT NULL,
    changed_by INT NULL,
    remarks TEXT NULL,
    changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES requests(id) ON DELETE CASCADE,
    FOREIGN KEY (changed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Default admin account
--   email: admin@acc.edu.ph
--   password: admin123   (CHANGE THIS AFTER FIRST LOGIN)
-- ---------------------------------------------------------
INSERT INTO users (full_name, email, password, role) VALUES
('ACC Registrar Admin', 'admin@acc.edu.ph', '$2b$12$YK95TiYxDEMG9W7UTqciCunfUrJd8gF.rjnrmcU2cEGTSIjMcSk9i', 'admin');

-- ---------------------------------------------------------
-- Sample student account
--   email: juan@student.acc.edu.ph
--   password: admin123   (CHANGE THIS AFTER FIRST LOGIN)
-- ---------------------------------------------------------
INSERT INTO users (student_id, full_name, email, password, role, course, year_level, contact_number) VALUES
('ACC-2024-0001', 'Juan Dela Cruz', 'juan@student.acc.edu.ph', '$2b$12$YK95TiYxDEMG9W7UTqciCunfUrJd8gF.rjnrmcU2cEGTSIjMcSk9i', 'student', 'BS Information Technology', '3rd Year', '09171234567');
