<?php
require_once __DIR__ . '/lib/functions.php';

if (is_logged_in()) {
    if (current_role() === 'admin') {
        redirect('/views/admin/dashboard.php');
    } else {
        redirect('/views/student/dashboard.php');
    }
}

redirect('/login.php');
