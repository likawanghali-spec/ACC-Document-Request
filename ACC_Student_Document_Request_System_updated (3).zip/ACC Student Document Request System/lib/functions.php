<?php
/**
 * ACC Student Document Request System
 * Shared helper functions
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/** Escape output safely */
function h($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Base URL of the app, auto-detected from where this project folder
 * actually sits under the web server's document root. This means
 * redirect('/login.php') keeps working whether the app is installed at
 * http://localhost/ or http://localhost/ACC Student Document Request System/
 * or any other subfolder/name.
 */
if (!defined('BASE_URL')) {
    $docRoot = str_replace('\\', '/', rtrim($_SERVER['DOCUMENT_ROOT'] ?? '', '/\\'));
    $appRoot = str_replace('\\', '/', rtrim(dirname(__DIR__), '/\\')); // parent of lib/ = project root
    $base = '';
    if ($docRoot !== '' && strpos($appRoot, $docRoot) === 0) {
        $base = substr($appRoot, strlen($docRoot));
    }
    define('BASE_URL', $base);
}

/** Redirect helper (paths starting with "/" are relative to the app's own folder) */
function redirect($url) {
    if (isset($url[0]) && $url[0] === '/') {
        $url = BASE_URL . $url;
    }
    header("Location: $url");
    exit;
}

/** Is a user currently logged in? */
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

/** Current user's role, or null */
function current_role() {
    return $_SESSION['role'] ?? null;
}

/** Force login, otherwise send to login page */
function require_login() {
    if (!is_logged_in()) {
        redirect('/login.php');
    }
}

/** Force a specific role, otherwise send home */
function require_role($role) {
    require_login();
    if (current_role() !== $role) {
        redirect('/index.php');
    }
}

/** Flash message helpers (session-based, one-time) */
function set_flash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function get_flash() {
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/** Generate a unique human-readable tracking number, e.g. ACC-2026-00042 */
function generate_tracking_no($pdo) {
    $year = date('Y');
    $stmt = $pdo->prepare("SELECT COUNT(*) AS cnt FROM requests WHERE tracking_no LIKE ?");
    $stmt->execute(["ACC-$year-%"]);
    $count = (int) $stmt->fetch()['cnt'] + 1;
    return sprintf("ACC-%s-%05d", $year, $count);
}

/** Map a status to a CSS badge class */
function status_badge_class($status) {
    $map = [
        'Pending'          => 'badge-pending',
        'Processing'       => 'badge-processing',
        'Approved'         => 'badge-approved',
        'Ready for Pickup' => 'badge-ready',
        'Released'         => 'badge-released',
        'Rejected'         => 'badge-rejected',
    ];
    return $map[$status] ?? 'badge-pending';
}
