<?php
require_once __DIR__ . '/lib/functions.php';

if (is_logged_in()) {
    redirect(current_role() === 'admin' ? '/views/admin/dashboard.php' : '/views/student/dashboard.php');
}

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login | ACC Document Request System</title>
<link rel="icon" type="image/png" href="assets/img/logo.png">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-page">

<div class="auth-card">
    <div class="auth-logo">
        <img src="assets/img/logo.png" alt="ACC Logo" class="logo-circle">
    </div>
    <h1>Student Document Request</h1>
    <p class="subtitle">Abuyog Community College</p>

    <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'error' ?>">
            <?= h($flash['message']) ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="controller/AuthController.php">
        <input type="hidden" name="action" value="login">

        <div class="form-group">
            <label for="email">Email Address</label>
            <input type="email" id="email" name="email" placeholder="you@example.com" required autofocus>
        </div>

        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" placeholder="••••••••" required>
        </div>

        <button type="submit" class="btn btn-primary">Log In</button>
    </form>

    <div class="auth-footer">
        Don't have an account? <a href="register.php">Register here</a>
    </div>
</div>

<script src="assets/js/script.js"></script>
</body>
</html>
