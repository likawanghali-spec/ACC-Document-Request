<?php
/**
 * ACC Student Document Request System
 * DocumentRequest model
 */

class DocumentRequest {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function create($studentId, $documentTypeId, $purpose, $copies) {
        $trackingNo = generate_tracking_no($this->pdo);

        $stmt = $this->pdo->prepare(
            "INSERT INTO requests (tracking_no, student_id, document_type_id, purpose, number_of_copies, status)
             VALUES (?, ?, ?, ?, ?, 'Pending')"
        );
        $stmt->execute([$trackingNo, $studentId, $documentTypeId, $purpose, $copies]);
        $requestId = $this->pdo->lastInsertId();

        $this->logStatus($requestId, null, 'Pending', $studentId, 'Request submitted by student.');

        return $trackingNo;
    }

    public function findById($id) {
        $stmt = $this->pdo->prepare(
            "SELECT r.*, dt.name AS document_name, dt.processing_days,
                    u.full_name AS student_name, u.student_id AS student_no, u.course, u.year_level
             FROM requests r
             JOIN document_types dt ON dt.id = r.document_type_id
             JOIN users u ON u.id = r.student_id
             WHERE r.id = ?"
        );
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function forStudent($studentId) {
        $stmt = $this->pdo->prepare(
            "SELECT r.*, dt.name AS document_name
             FROM requests r
             JOIN document_types dt ON dt.id = r.document_type_id
             WHERE r.student_id = ?
             ORDER BY r.date_requested DESC"
        );
        $stmt->execute([$studentId]);
        return $stmt->fetchAll();
    }

    public function all($statusFilter = null, $search = null) {
        $sql = "SELECT r.*, dt.name AS document_name,
                       u.full_name AS student_name, u.student_id AS student_no
                FROM requests r
                JOIN document_types dt ON dt.id = r.document_type_id
                JOIN users u ON u.id = r.student_id
                WHERE 1=1";
        $params = [];

        if ($statusFilter) {
            $sql .= " AND r.status = ?";
            $params[] = $statusFilter;
        }
        if ($search) {
            $sql .= " AND (u.full_name LIKE ? OR u.student_id LIKE ? OR r.tracking_no LIKE ?)";
            $like = "%$search%";
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        $sql .= " ORDER BY r.date_requested DESC";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function updateStatus($requestId, $newStatus, $adminId, $remarks = null) {
        $current = $this->findById($requestId);
        if (!$current) return false;

        $stmt = $this->pdo->prepare(
            "UPDATE requests SET status = ?, remarks = ?, processed_by = ? WHERE id = ?"
        );
        $stmt->execute([$newStatus, $remarks, $adminId, $requestId]);

        $this->logStatus($requestId, $current['status'], $newStatus, $adminId, $remarks);
        return true;
    }

    public function logStatus($requestId, $oldStatus, $newStatus, $changedBy, $remarks = null) {
        $stmt = $this->pdo->prepare(
            "INSERT INTO request_status_log (request_id, old_status, new_status, changed_by, remarks)
             VALUES (?, ?, ?, ?, ?)"
        );
        $stmt->execute([$requestId, $oldStatus, $newStatus, $changedBy, $remarks]);
    }

    public function history($requestId) {
        $stmt = $this->pdo->prepare(
            "SELECT l.*, u.full_name AS changed_by_name
             FROM request_status_log l
             LEFT JOIN users u ON u.id = l.changed_by
             WHERE l.request_id = ?
             ORDER BY l.changed_at ASC"
        );
        $stmt->execute([$requestId]);
        return $stmt->fetchAll();
    }

    public function counts() {
        $stmt = $this->pdo->query(
            "SELECT status, COUNT(*) AS total FROM requests GROUP BY status"
        );
        $rows = $stmt->fetchAll();
        $counts = [
            'Pending' => 0, 'Processing' => 0, 'Approved' => 0,
            'Ready for Pickup' => 0, 'Released' => 0, 'Rejected' => 0,
        ];
        foreach ($rows as $row) {
            $counts[$row['status']] = (int) $row['total'];
        }
        return $counts;
    }
}
