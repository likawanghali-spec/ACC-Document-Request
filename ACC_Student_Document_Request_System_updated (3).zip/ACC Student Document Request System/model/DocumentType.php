<?php
/**
 * ACC Student Document Request System
 * DocumentType model
 */

class DocumentType {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function all() {
        $stmt = $this->pdo->query(
            "SELECT * FROM document_types WHERE is_active = 1 ORDER BY name ASC"
        );
        return $stmt->fetchAll();
    }

    public function find($id) {
        $stmt = $this->pdo->prepare("SELECT * FROM document_types WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }
}
