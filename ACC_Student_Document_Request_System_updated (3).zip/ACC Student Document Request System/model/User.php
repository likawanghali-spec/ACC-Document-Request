<?php
/**
 * ACC Student Document Request System
 * User model
 */

class User {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function findByEmail($email) {
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        return $stmt->fetch();
    }

    public function findById($id) {
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch();
    }

    public function emailExists($email) {
        $stmt = $this->pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        return (bool) $stmt->fetch();
    }

    public function studentIdExists($studentId) {
        $stmt = $this->pdo->prepare("SELECT id FROM users WHERE student_id = ?");
        $stmt->execute([$studentId]);
        return (bool) $stmt->fetch();
    }

    public function createStudent($data) {
        $stmt = $this->pdo->prepare(
            "INSERT INTO users (student_id, full_name, email, password, role, course, year_level, contact_number)
             VALUES (?, ?, ?, ?, 'student', ?, ?, ?)"
        );
        return $stmt->execute([
            $data['student_id'],
            $data['full_name'],
            $data['email'],
            password_hash($data['password'], PASSWORD_DEFAULT),
            $data['course'],
            $data['year_level'],
            $data['contact_number'],
        ]);
    }

    public function verifyPassword($plain, $hash) {
        return password_verify($plain, $hash);
    }

    public function allStudents() {
        $stmt = $this->pdo->query(
            "SELECT * FROM users WHERE role = 'student' ORDER BY full_name ASC"
        );
        return $stmt->fetchAll();
    }

    public function countStudents() {
        return (int) $this->pdo->query("SELECT COUNT(*) c FROM users WHERE role = 'student'")->fetch()['c'];
    }
}
