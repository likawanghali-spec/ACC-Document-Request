<?php
require_once __DIR__ . '/lib/functions.php';

if (is_logged_in()) {
    redirect(current_role() === 'admin' ? '/views/admin/dashboard.php' : '/views/student/dashboard.php');
}

$flash = get_flash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register | ACC Document Request System</title>
<link rel="icon" type="image/png" href="assets/img/logo.png">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="auth-page">

<div class="auth-card wide">
    <div class="auth-logo">
        <img src="assets/img/logo.png" alt="ACC Logo" class="logo-circle">
    </div>
    <h1>Create Student Account</h1>
    <p class="subtitle">Abuyog Community College</p>

    <?php if ($flash): ?>
        <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'error' ?>">
            <?= h($flash['message']) ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="controller/AuthController.php" id="registerForm">
        <input type="hidden" name="action" value="register">

        <div class="form-row">
            <div class="form-group">
                <label for="student_id">Student ID Number *</label>
                <input type="text" id="student_id" name="student_id" placeholder="ACC-2024-0000" required>
            </div>
            <div class="form-group">
                <label for="full_name">Full Name *</label>
                <input type="text" id="full_name" name="full_name" placeholder="Juan Dela Cruz" required>
            </div>
        </div>

        <div class="form-group">
            <label for="email">Email Address *</label>
            <input type="email" id="email" name="email" placeholder="you@example.com" required>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="course">Course / Program</label>
                <input type="text" id="course" name="course" placeholder="BS Information Technology">
            </div>
            <div class="form-group">
                <label for="year_level">Year Level</label>
                <select id="year_level" name="year_level">
                    <option value="">Select year level</option>
                    <option>1st Year</option>
                    <option>2nd Year</option>
                    <option>3rd Year</option>
                    <option>4th Year</option>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label for="contact_number">Contact Number</label>
            <input type="text" id="contact_number" name="contact_number" placeholder="09XXXXXXXXX">
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="password">Password *</label>
                <input type="password" id="password" name="password" placeholder="At least 6 characters" required>
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm Password *</label>
                <input type="password" id="confirm_password" name="confirm_password" placeholder="Re-enter password" required>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Create Account</button>
    </form>

    <div class="auth-footer">
        Already have an account? <a href="login.php">Log in</a>
    </div>
</div>

<script src="assets/js/script.js"></script>
</body>
</html>
