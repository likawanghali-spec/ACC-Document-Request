<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/functions.php';
require_once __DIR__ . '/../../model/DocumentRequest.php';
require_once __DIR__ . '/../../model/User.php';

require_role('admin');

$requestModel = new DocumentRequest($pdo);
$userModel = new User($pdo);

$counts = $requestModel->counts();
$totalStudents = $userModel->countStudents();
$recent = array_slice($requestModel->all(), 0, 8);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard | ACC Document Request System</title>
<link rel="icon" type="image/png" href="../../assets/img/logo.png">
<link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>

<?php include __DIR__ . '/../partials/admin_nav.php'; ?>

<div class="main-content">
    <div class="page-header">
        <div>
            <h1>Staff Dashboard</h1>
            <p>Overview of all student document requests.</p>
        </div>
        <a href="manage_requests.php" class="btn btn-primary">Manage Requests</a>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-number"><?= $totalStudents ?></div>
            <div class="stat-label">Registered Students</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $counts['Pending'] ?></div>
            <div class="stat-label">Pending</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $counts['Processing'] + $counts['Approved'] ?></div>
            <div class="stat-label">Processing / Approved</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $counts['Ready for Pickup'] ?></div>
            <div class="stat-label">Ready for Pickup</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $counts['Released'] ?></div>
            <div class="stat-label">Released</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $counts['Rejected'] ?></div>
            <div class="stat-label">Rejected</div>
        </div>
    </div>

    <div class="card">
        <h2>Recent Requests</h2>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Tracking No.</th>
                        <th>Student</th>
                        <th>Document</th>
                        <th>Date Requested</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($recent)): ?>
                    <tr><td colspan="5" class="empty-state">No requests submitted yet.</td></tr>
                <?php else: foreach ($recent as $r): ?>
                    <tr>
                        <td><?= h($r['tracking_no']) ?></td>
                        <td><?= h($r['student_name']) ?> <span class="text-muted">(<?= h($r['student_no']) ?>)</span></td>
                        <td><?= h($r['document_name']) ?></td>
                        <td><?= date('M d, Y', strtotime($r['date_requested'])) ?></td>
                        <td><span class="badge <?= status_badge_class($r['status']) ?>"><?= h($r['status']) ?></span></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <p style="margin-top:14px;"><a href="manage_requests.php">View and manage all requests &rarr;</a></p>
    </div>
</div>

<footer class="site-footer">ACC Student Document Request System &copy; <?= date('Y') ?> Abuyog Community College</footer>
<script src="../../assets/js/script.js"></script>
</body>
</html>
