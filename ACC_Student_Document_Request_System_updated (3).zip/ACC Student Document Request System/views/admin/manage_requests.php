<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/functions.php';
require_once __DIR__ . '/../../model/DocumentRequest.php';

require_role('admin');

$requestModel = new DocumentRequest($pdo);

$statusFilter = $_GET['status'] ?? '';
$search = trim($_GET['q'] ?? '');

$requests = $requestModel->all($statusFilter ?: null, $search ?: null);

$statuses = ['Pending', 'Processing', 'Approved', 'Ready for Pickup', 'Released', 'Rejected'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Manage Requests | ACC Document Request System</title>
<link rel="icon" type="image/png" href="../../assets/img/logo.png">
<link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>

<?php include __DIR__ . '/../partials/admin_nav.php'; ?>

<div class="main-content">
    <div class="page-header">
        <div>
            <h1>Manage Requests</h1>
            <p>Review, approve, and update the status of student document requests.</p>
        </div>
    </div>

    <form method="GET" class="filters">
        <select name="status" id="statusFilter">
            <option value="">All Statuses</option>
            <?php foreach ($statuses as $s): ?>
                <option value="<?= h($s) ?>" <?= $statusFilter === $s ? 'selected' : '' ?>><?= h($s) ?></option>
            <?php endforeach; ?>
        </select>
        <input type="text" name="q" placeholder="Search student, ID, or tracking no." value="<?= h($search) ?>">
        <button type="submit" class="btn btn-outline btn-sm">Filter</button>
        <?php if ($statusFilter || $search): ?>
            <a href="manage_requests.php" class="btn btn-sm" style="align-self:center;">Clear</a>
        <?php endif; ?>
    </form>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Tracking No.</th>
                    <th>Student</th>
                    <th>Document</th>
                    <th>Purpose</th>
                    <th>Copies</th>
                    <th>Date Requested</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($requests)): ?>
                <tr><td colspan="8" class="empty-state">No matching requests found.</td></tr>
            <?php else: foreach ($requests as $r): ?>
                <tr>
                    <td><?= h($r['tracking_no']) ?></td>
                    <td><?= h($r['student_name']) ?><br><span class="text-muted"><?= h($r['student_no']) ?></span></td>
                    <td><?= h($r['document_name']) ?></td>
                    <td><?= h($r['purpose']) ?></td>
                    <td><?= (int) $r['number_of_copies'] ?></td>
                    <td><?= date('M d, Y', strtotime($r['date_requested'])) ?></td>
                    <td><span class="badge <?= status_badge_class($r['status']) ?>"><?= h($r['status']) ?></span></td>
                    <td>
                        <button type="button" class="btn btn-outline btn-sm js-toggle-update" data-target="update-<?= $r['id'] ?>">Update</button>
                    </td>
                </tr>
                <tr id="update-<?= $r['id'] ?>" style="display:none; background:#f4f7f5;">
                    <td colspan="8">
                        <form method="POST" action="../../controller/RequestController.php" style="display:flex; gap:10px; align-items:center; flex-wrap:wrap; padding:8px 0;">
                            <input type="hidden" name="action" value="update_status">
                            <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                            <select name="status" style="max-width:200px;">
                                <?php foreach ($statuses as $s): ?>
                                    <option value="<?= h($s) ?>" <?= $r['status'] === $s ? 'selected' : '' ?>><?= h($s) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <input type="text" name="remarks" placeholder="Remarks (optional)" value="<?= h($r['remarks'] ?? '') ?>" style="flex:1; min-width:200px;">
                            <button type="submit" class="btn btn-primary btn-sm" style="width:auto;">Save</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<footer class="site-footer">ACC Student Document Request System &copy; <?= date('Y') ?> Abuyog Community College</footer>
<script src="../../assets/js/script.js"></script>
</body>
</html>
