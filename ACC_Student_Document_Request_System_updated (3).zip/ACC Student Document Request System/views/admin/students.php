<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/functions.php';
require_once __DIR__ . '/../../model/User.php';

require_role('admin');

$userModel = new User($pdo);
$students = $userModel->allStudents();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Students | ACC Document Request System</title>
<link rel="icon" type="image/png" href="../../assets/img/logo.png">
<link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>

<?php include __DIR__ . '/../partials/admin_nav.php'; ?>

<div class="main-content">
    <div class="page-header">
        <div>
            <h1>Registered Students</h1>
            <p>All student accounts registered in the system.</p>
        </div>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Course</th>
                    <th>Year Level</th>
                    <th>Contact No.</th>
                    <th>Registered</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($students)): ?>
                <tr><td colspan="7" class="empty-state">No students registered yet.</td></tr>
            <?php else: foreach ($students as $s): ?>
                <tr>
                    <td><?= h($s['student_id']) ?></td>
                    <td><?= h($s['full_name']) ?></td>
                    <td><?= h($s['email']) ?></td>
                    <td><?= h($s['course'] ?: '—') ?></td>
                    <td><?= h($s['year_level'] ?: '—') ?></td>
                    <td><?= h($s['contact_number'] ?: '—') ?></td>
                    <td><?= date('M d, Y', strtotime($s['created_at'])) ?></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<footer class="site-footer">ACC Student Document Request System &copy; <?= date('Y') ?> Abuyog Community College</footer>
<script src="../../assets/js/script.js"></script>
</body>
</html>
