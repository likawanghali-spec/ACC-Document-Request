<?php
$flash = get_flash();
$current = basename($_SERVER['SCRIPT_NAME']);

$titles = [
    'dashboard.php'       => 'Dashboard',
    'submit_request.php'  => 'Submit Request',
    'my_requests.php'     => 'My Requests',
];
$pageTitle = $titles[$current] ?? ucwords(str_replace('_', ' ', pathinfo($current, PATHINFO_FILENAME)));
?>
<div class="sidebar">
    <div class="brand">
        <img src="../../assets/img/logo.png" alt="ACC Logo" class="logo-circle">
        <span>ACC Document Request</span>
    </div>

    <div class="user-chip"><?= h($_SESSION['full_name']) ?></div>

    <nav class="sidebar-links">
        <a href="dashboard.php" class="<?= $current === 'dashboard.php' ? 'active' : '' ?>">Dashboard</a>
        <a href="submit_request.php" class="<?= $current === 'submit_request.php' ? 'active' : '' ?>">New Request</a>
        <a href="my_requests.php" class="<?= $current === 'my_requests.php' ? 'active' : '' ?>">My Requests</a>
    </nav>

    <form method="POST" action="../../controller/AuthController.php">
        <input type="hidden" name="action" value="logout">
        <button type="submit" class="btn-logout">Logout</button>
    </form>
</div>

<div class="topbar">
    <div class="topbar-left">
        <button type="button" class="sidebar-toggle" aria-label="Toggle menu">&#9776;</button>
        <h2 class="topbar-title"><?= h($pageTitle) ?></h2>
    </div>
    <div class="topbar-right">
        <span class="user-chip"><span class="chip-label"><?= h($_SESSION['full_name']) ?></span></span>
    </div>
</div>

<?php if (!empty($flash)): ?>
<div class="main-content" style="padding-bottom:0; margin-bottom:-10px;">
    <div class="alert alert-<?= $flash['type'] === 'success' ? 'success' : 'error' ?>"><?= h($flash['message']) ?></div>
</div>
<?php endif; ?>
