<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/functions.php';
require_once __DIR__ . '/../../model/DocumentRequest.php';

require_role('student');

$requestModel = new DocumentRequest($pdo);
$myRequests = $requestModel->forStudent($_SESSION['user_id']);

$total = count($myRequests);
$pending = count(array_filter($myRequests, fn($r) => $r['status'] === 'Pending'));
$processing = count(array_filter($myRequests, fn($r) => in_array($r['status'], ['Processing', 'Approved'])));
$ready = count(array_filter($myRequests, fn($r) => $r['status'] === 'Ready for Pickup'));
$released = count(array_filter($myRequests, fn($r) => $r['status'] === 'Released'));

$recent = array_slice($myRequests, 0, 5);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Dashboard | ACC Document Request System</title>
<link rel="icon" type="image/png" href="../../assets/img/logo.png">
<link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>

<?php include __DIR__ . '/../partials/student_nav.php'; ?>

<div class="main-content">
    <div class="page-header">
        <div>
            <h1>Welcome, <?= h($_SESSION['full_name']) ?></h1>
            <p>Here's an overview of your document requests.</p>
        </div>
        <a href="submit_request.php" class="btn btn-primary">+ New Request</a>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-number"><?= $total ?></div>
            <div class="stat-label">Total Requests</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $pending ?></div>
            <div class="stat-label">Pending</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $processing ?></div>
            <div class="stat-label">Processing / Approved</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $ready ?></div>
            <div class="stat-label">Ready for Pickup</div>
        </div>
        <div class="stat-card">
            <div class="stat-number"><?= $released ?></div>
            <div class="stat-label">Released</div>
        </div>
    </div>

    <div class="card">
        <h2>Recent Requests</h2>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Tracking No.</th>
                        <th>Document</th>
                        <th>Date Requested</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($recent)): ?>
                    <tr><td colspan="4" class="empty-state">You haven't submitted any requests yet.</td></tr>
                <?php else: foreach ($recent as $r): ?>
                    <tr>
                        <td><?= h($r['tracking_no']) ?></td>
                        <td><?= h($r['document_name']) ?></td>
                        <td><?= date('M d, Y', strtotime($r['date_requested'])) ?></td>
                        <td><span class="badge <?= status_badge_class($r['status']) ?>"><?= h($r['status']) ?></span></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
        <p style="margin-top:14px;"><a href="my_requests.php">View all requests &rarr;</a></p>
    </div>
</div>

<footer class="site-footer">ACC Student Document Request System &copy; <?= date('Y') ?> Abuyog Community College</footer>
<script src="../../assets/js/script.js"></script>
</body>
</html>
