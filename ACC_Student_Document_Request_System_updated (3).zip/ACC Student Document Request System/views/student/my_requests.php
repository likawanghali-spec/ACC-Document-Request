<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/functions.php';
require_once __DIR__ . '/../../model/DocumentRequest.php';

require_role('student');

$requestModel = new DocumentRequest($pdo);
$myRequests = $requestModel->forStudent($_SESSION['user_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Requests | ACC Document Request System</title>
<link rel="icon" type="image/png" href="../../assets/img/logo.png">
<link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>

<?php include __DIR__ . '/../partials/student_nav.php'; ?>

<div class="main-content">
    <div class="page-header">
        <div>
            <h1>My Requests</h1>
            <p>Track the status of every document request you've submitted.</p>
        </div>
        <a href="submit_request.php" class="btn btn-primary">+ New Request</a>
    </div>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Tracking No.</th>
                    <th>Document</th>
                    <th>Purpose</th>
                    <th>Copies</th>
                    <th>Date Requested</th>
                    <th>Status</th>
                    <th>Remarks</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($myRequests)): ?>
                <tr><td colspan="7" class="empty-state">You haven't submitted any requests yet. <a href="submit_request.php">Submit one now &rarr;</a></td></tr>
            <?php else: foreach ($myRequests as $r): ?>
                <tr>
                    <td><?= h($r['tracking_no']) ?></td>
                    <td><?= h($r['document_name']) ?></td>
                    <td><?= h($r['purpose']) ?></td>
                    <td><?= (int) $r['number_of_copies'] ?></td>
                    <td><?= date('M d, Y g:i A', strtotime($r['date_requested'])) ?></td>
                    <td><span class="badge <?= status_badge_class($r['status']) ?>"><?= h($r['status']) ?></span></td>
                    <td><?= $r['remarks'] ? h($r['remarks']) : '<span class="text-muted">—</span>' ?></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<footer class="site-footer">ACC Student Document Request System &copy; <?= date('Y') ?> Abuyog Community College</footer>
<script src="../../assets/js/script.js"></script>
</body>
</html>
