<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../lib/functions.php';
require_once __DIR__ . '/../../model/DocumentType.php';

require_role('student');

$docTypeModel = new DocumentType($pdo);
$documentTypes = $docTypeModel->all();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>New Request | ACC Document Request System</title>
<link rel="icon" type="image/png" href="../../assets/img/logo.png">
<link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>

<?php include __DIR__ . '/../partials/student_nav.php'; ?>

<div class="main-content">
    <div class="page-header">
        <div>
            <h1>Submit a Document Request</h1>
            <p>Choose the document you need and tell us your purpose. We'll notify you as your request moves forward.</p>
        </div>
    </div>

    <div class="card">
        <form method="POST" action="../../controller/RequestController.php" id="submitRequestForm">
            <input type="hidden" name="action" value="submit_request">

            <label>Select Document Type *</label>
            <div class="doc-type-grid">
                <?php foreach ($documentTypes as $dt): ?>
                    <label class="doc-type-option">
                        <input type="radio" name="document_type_id" value="<?= $dt['id'] ?>">
                        <strong><?= h($dt['name']) ?></strong>
                        <span class="desc"><?= h($dt['description']) ?> (~<?= (int)$dt['processing_days'] ?> processing day<?= $dt['processing_days'] > 1 ? 's' : '' ?>)</span>
                    </label>
                <?php endforeach; ?>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="purpose">Purpose *</label>
                    <input type="text" id="purpose" name="purpose" placeholder="e.g. Scholarship application, Job requirement" required>
                </div>
                <div class="form-group">
                    <label for="number_of_copies">Number of Copies</label>
                    <input type="number" id="number_of_copies" name="number_of_copies" value="1" min="1" max="10">
                </div>
            </div>

            <button type="submit" class="btn btn-primary" style="width:auto; padding:10px 30px;">Submit Request</button>
        </form>
    </div>
</div>

<footer class="site-footer">ACC Student Document Request System &copy; <?= date('Y') ?> Abuyog Community College</footer>
<script src="../../assets/js/script.js"></script>
</body>
</html>
